# Bilaash by SAHA — Android wrapper project

This project wraps the live Bilaash web app in an Android WebView and includes a GitHub Actions workflow that builds a **debug APK**.

## Important
- This is Android source code, **not a compiled APK**.
- The wrapper loads `https://bilaash-zp68f0.v2.appdeploy.ai/`; login and messaging require an internet connection.
- The debug APK is unsigned for Play Store distribution, but can generally be installed manually after allowing installs from the source app.
- Do not share the APK publicly unless you control the app and its backend.

## Build the APK using GitHub Actions
1. Download and extract this ZIP.
2. Create a GitHub repository and upload the extracted files.
3. Open the repository's **Actions** tab.
4. Enable Actions if prompted, then run **Build Bilaash APK** using **Run workflow**.
5. When the workflow finishes, open its run page and download the `Bilaash-debug-apk` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`, then transfer it to your Android phone and install it.

## Build locally
Requires JDK 17, Android SDK (API 35), and Gradle 8.9:
```bash
gradle assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk`
